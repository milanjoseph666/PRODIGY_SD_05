import requests
from bs4 import BeautifulSoup
import csv

url = "http://books.toscrape.com/catalogue/page-1.html"
headers = {"User-Agent": "Mozilla/5.0"}

response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.content, "html.parser")
books = soup.find_all("article", class_="product_pod")

data = []
for book in books:
    name = book.h3.a["title"]
    price = book.find("p", class_="price_color").text.strip()
    rating = book.p["class"][1]
    data.append([name, price, rating])

with open("books.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Price", "Rating"])
    writer.writerows(data)

print("Scraping completed and saved to books.csv")