# Web Scraping Task

This Python script scrapes book information (title, price, rating) from http://books.toscrape.com and saves it into a CSV file.

## Requirements
- Python 3.x
- requests
- beautifulsoup4

## How to Run
1. Install dependencies:
   pip install requests beautifulsoup4

2. Run the script:
   python web_scraper.py

The scraped data will be saved in `books.csv`.